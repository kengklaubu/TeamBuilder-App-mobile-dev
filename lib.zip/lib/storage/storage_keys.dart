class StorageKeys {
  static const teamName = 'team_name';
  static const teamIds = 'team_ids'; // List<int>
  static const teams = 'teams'; // List<Map>

}
